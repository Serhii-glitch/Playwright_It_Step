/*
 Quantcast measurement tag
 Copyright (c) 2008-2023, Quantcast Corp.
*/
'use strict';(function(a,b,c){__qc("rules",[a])})("p-jvu6JC2_EEYyU",window,document);